/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 3.0, "minX": 0.0, "maxY": 1330.0, "series": [{"data": [[0.0, 3.0], [0.1, 4.0], [0.2, 12.0], [0.3, 12.0], [0.4, 13.0], [0.5, 13.0], [0.6, 13.0], [0.7, 13.0], [0.8, 13.0], [0.9, 13.0], [1.0, 13.0], [1.1, 13.0], [1.2, 13.0], [1.3, 13.0], [1.4, 13.0], [1.5, 13.0], [1.6, 13.0], [1.7, 13.0], [1.8, 13.0], [1.9, 13.0], [2.0, 13.0], [2.1, 13.0], [2.2, 13.0], [2.3, 13.0], [2.4, 13.0], [2.5, 13.0], [2.6, 13.0], [2.7, 13.0], [2.8, 14.0], [2.9, 14.0], [3.0, 14.0], [3.1, 14.0], [3.2, 14.0], [3.3, 14.0], [3.4, 14.0], [3.5, 14.0], [3.6, 14.0], [3.7, 14.0], [3.8, 14.0], [3.9, 14.0], [4.0, 14.0], [4.1, 14.0], [4.2, 14.0], [4.3, 14.0], [4.4, 14.0], [4.5, 14.0], [4.6, 14.0], [4.7, 14.0], [4.8, 14.0], [4.9, 14.0], [5.0, 14.0], [5.1, 14.0], [5.2, 14.0], [5.3, 14.0], [5.4, 14.0], [5.5, 14.0], [5.6, 14.0], [5.7, 14.0], [5.8, 14.0], [5.9, 14.0], [6.0, 14.0], [6.1, 14.0], [6.2, 14.0], [6.3, 14.0], [6.4, 14.0], [6.5, 14.0], [6.6, 14.0], [6.7, 14.0], [6.8, 14.0], [6.9, 14.0], [7.0, 14.0], [7.1, 14.0], [7.2, 14.0], [7.3, 14.0], [7.4, 14.0], [7.5, 14.0], [7.6, 14.0], [7.7, 14.0], [7.8, 14.0], [7.9, 15.0], [8.0, 15.0], [8.1, 15.0], [8.2, 15.0], [8.3, 15.0], [8.4, 15.0], [8.5, 15.0], [8.6, 15.0], [8.7, 15.0], [8.8, 15.0], [8.9, 15.0], [9.0, 15.0], [9.1, 15.0], [9.2, 15.0], [9.3, 15.0], [9.4, 15.0], [9.5, 15.0], [9.6, 15.0], [9.7, 15.0], [9.8, 15.0], [9.9, 15.0], [10.0, 15.0], [10.1, 15.0], [10.2, 15.0], [10.3, 15.0], [10.4, 15.0], [10.5, 15.0], [10.6, 15.0], [10.7, 16.0], [10.8, 16.0], [10.9, 16.0], [11.0, 16.0], [11.1, 16.0], [11.2, 16.0], [11.3, 16.0], [11.4, 16.0], [11.5, 16.0], [11.6, 16.0], [11.7, 16.0], [11.8, 16.0], [11.9, 16.0], [12.0, 16.0], [12.1, 16.0], [12.2, 16.0], [12.3, 16.0], [12.4, 16.0], [12.5, 16.0], [12.6, 16.0], [12.7, 16.0], [12.8, 16.0], [12.9, 17.0], [13.0, 17.0], [13.1, 17.0], [13.2, 17.0], [13.3, 17.0], [13.4, 17.0], [13.5, 17.0], [13.6, 17.0], [13.7, 17.0], [13.8, 17.0], [13.9, 17.0], [14.0, 17.0], [14.1, 17.0], [14.2, 17.0], [14.3, 17.0], [14.4, 17.0], [14.5, 17.0], [14.6, 17.0], [14.7, 17.0], [14.8, 17.0], [14.9, 18.0], [15.0, 18.0], [15.1, 18.0], [15.2, 18.0], [15.3, 18.0], [15.4, 18.0], [15.5, 18.0], [15.6, 18.0], [15.7, 18.0], [15.8, 18.0], [15.9, 18.0], [16.0, 18.0], [16.1, 18.0], [16.2, 18.0], [16.3, 18.0], [16.4, 18.0], [16.5, 19.0], [16.6, 19.0], [16.7, 19.0], [16.8, 19.0], [16.9, 19.0], [17.0, 19.0], [17.1, 19.0], [17.2, 19.0], [17.3, 19.0], [17.4, 19.0], [17.5, 19.0], [17.6, 19.0], [17.7, 19.0], [17.8, 19.0], [17.9, 19.0], [18.0, 19.0], [18.1, 19.0], [18.2, 19.0], [18.3, 19.0], [18.4, 19.0], [18.5, 19.0], [18.6, 19.0], [18.7, 19.0], [18.8, 19.0], [18.9, 19.0], [19.0, 19.0], [19.1, 20.0], [19.2, 20.0], [19.3, 20.0], [19.4, 20.0], [19.5, 20.0], [19.6, 20.0], [19.7, 20.0], [19.8, 20.0], [19.9, 20.0], [20.0, 20.0], [20.1, 20.0], [20.2, 20.0], [20.3, 20.0], [20.4, 20.0], [20.5, 20.0], [20.6, 20.0], [20.7, 21.0], [20.8, 21.0], [20.9, 21.0], [21.0, 21.0], [21.1, 21.0], [21.2, 21.0], [21.3, 21.0], [21.4, 21.0], [21.5, 21.0], [21.6, 21.0], [21.7, 21.0], [21.8, 21.0], [21.9, 21.0], [22.0, 21.0], [22.1, 22.0], [22.2, 22.0], [22.3, 22.0], [22.4, 22.0], [22.5, 22.0], [22.6, 22.0], [22.7, 22.0], [22.8, 22.0], [22.9, 22.0], [23.0, 22.0], [23.1, 22.0], [23.2, 22.0], [23.3, 22.0], [23.4, 22.0], [23.5, 22.0], [23.6, 22.0], [23.7, 22.0], [23.8, 22.0], [23.9, 22.0], [24.0, 22.0], [24.1, 22.0], [24.2, 23.0], [24.3, 23.0], [24.4, 23.0], [24.5, 23.0], [24.6, 23.0], [24.7, 23.0], [24.8, 23.0], [24.9, 23.0], [25.0, 23.0], [25.1, 23.0], [25.2, 23.0], [25.3, 23.0], [25.4, 23.0], [25.5, 23.0], [25.6, 23.0], [25.7, 24.0], [25.8, 24.0], [25.9, 24.0], [26.0, 24.0], [26.1, 24.0], [26.2, 24.0], [26.3, 24.0], [26.4, 24.0], [26.5, 24.0], [26.6, 24.0], [26.7, 24.0], [26.8, 25.0], [26.9, 25.0], [27.0, 25.0], [27.1, 25.0], [27.2, 25.0], [27.3, 25.0], [27.4, 25.0], [27.5, 25.0], [27.6, 25.0], [27.7, 25.0], [27.8, 25.0], [27.9, 25.0], [28.0, 25.0], [28.1, 25.0], [28.2, 25.0], [28.3, 25.0], [28.4, 25.0], [28.5, 25.0], [28.6, 25.0], [28.7, 26.0], [28.8, 26.0], [28.9, 26.0], [29.0, 26.0], [29.1, 26.0], [29.2, 26.0], [29.3, 26.0], [29.4, 26.0], [29.5, 26.0], [29.6, 26.0], [29.7, 26.0], [29.8, 26.0], [29.9, 26.0], [30.0, 26.0], [30.1, 26.0], [30.2, 26.0], [30.3, 26.0], [30.4, 26.0], [30.5, 26.0], [30.6, 27.0], [30.7, 27.0], [30.8, 27.0], [30.9, 27.0], [31.0, 27.0], [31.1, 27.0], [31.2, 27.0], [31.3, 27.0], [31.4, 27.0], [31.5, 27.0], [31.6, 27.0], [31.7, 28.0], [31.8, 28.0], [31.9, 28.0], [32.0, 28.0], [32.1, 28.0], [32.2, 28.0], [32.3, 28.0], [32.4, 28.0], [32.5, 28.0], [32.6, 28.0], [32.7, 28.0], [32.8, 29.0], [32.9, 29.0], [33.0, 29.0], [33.1, 29.0], [33.2, 29.0], [33.3, 29.0], [33.4, 29.0], [33.5, 29.0], [33.6, 29.0], [33.7, 30.0], [33.8, 30.0], [33.9, 30.0], [34.0, 30.0], [34.1, 30.0], [34.2, 30.0], [34.3, 30.0], [34.4, 31.0], [34.5, 31.0], [34.6, 31.0], [34.7, 31.0], [34.8, 31.0], [34.9, 31.0], [35.0, 31.0], [35.1, 31.0], [35.2, 31.0], [35.3, 32.0], [35.4, 32.0], [35.5, 32.0], [35.6, 32.0], [35.7, 32.0], [35.8, 32.0], [35.9, 32.0], [36.0, 32.0], [36.1, 33.0], [36.2, 33.0], [36.3, 33.0], [36.4, 33.0], [36.5, 33.0], [36.6, 33.0], [36.7, 33.0], [36.8, 33.0], [36.9, 33.0], [37.0, 34.0], [37.1, 34.0], [37.2, 34.0], [37.3, 34.0], [37.4, 34.0], [37.5, 34.0], [37.6, 34.0], [37.7, 34.0], [37.8, 34.0], [37.9, 34.0], [38.0, 34.0], [38.1, 35.0], [38.2, 35.0], [38.3, 35.0], [38.4, 35.0], [38.5, 35.0], [38.6, 35.0], [38.7, 35.0], [38.8, 35.0], [38.9, 35.0], [39.0, 35.0], [39.1, 35.0], [39.2, 35.0], [39.3, 35.0], [39.4, 35.0], [39.5, 35.0], [39.6, 35.0], [39.7, 35.0], [39.8, 36.0], [39.9, 36.0], [40.0, 36.0], [40.1, 36.0], [40.2, 36.0], [40.3, 36.0], [40.4, 37.0], [40.5, 37.0], [40.6, 37.0], [40.7, 37.0], [40.8, 37.0], [40.9, 37.0], [41.0, 37.0], [41.1, 37.0], [41.2, 37.0], [41.3, 37.0], [41.4, 38.0], [41.5, 38.0], [41.6, 38.0], [41.7, 38.0], [41.8, 38.0], [41.9, 38.0], [42.0, 39.0], [42.1, 39.0], [42.2, 39.0], [42.3, 39.0], [42.4, 39.0], [42.5, 39.0], [42.6, 39.0], [42.7, 39.0], [42.8, 40.0], [42.9, 40.0], [43.0, 40.0], [43.1, 40.0], [43.2, 41.0], [43.3, 41.0], [43.4, 41.0], [43.5, 41.0], [43.6, 41.0], [43.7, 41.0], [43.8, 41.0], [43.9, 41.0], [44.0, 42.0], [44.1, 42.0], [44.2, 42.0], [44.3, 42.0], [44.4, 42.0], [44.5, 42.0], [44.6, 42.0], [44.7, 42.0], [44.8, 42.0], [44.9, 42.0], [45.0, 42.0], [45.1, 42.0], [45.2, 42.0], [45.3, 43.0], [45.4, 43.0], [45.5, 43.0], [45.6, 43.0], [45.7, 43.0], [45.8, 43.0], [45.9, 43.0], [46.0, 44.0], [46.1, 44.0], [46.2, 44.0], [46.3, 44.0], [46.4, 44.0], [46.5, 44.0], [46.6, 44.0], [46.7, 45.0], [46.8, 45.0], [46.9, 45.0], [47.0, 45.0], [47.1, 45.0], [47.2, 45.0], [47.3, 45.0], [47.4, 45.0], [47.5, 46.0], [47.6, 46.0], [47.7, 46.0], [47.8, 46.0], [47.9, 46.0], [48.0, 46.0], [48.1, 46.0], [48.2, 46.0], [48.3, 46.0], [48.4, 47.0], [48.5, 47.0], [48.6, 47.0], [48.7, 47.0], [48.8, 47.0], [48.9, 47.0], [49.0, 48.0], [49.1, 48.0], [49.2, 48.0], [49.3, 48.0], [49.4, 48.0], [49.5, 49.0], [49.6, 49.0], [49.7, 49.0], [49.8, 49.0], [49.9, 49.0], [50.0, 49.0], [50.1, 49.0], [50.2, 49.0], [50.3, 49.0], [50.4, 49.0], [50.5, 49.0], [50.6, 49.0], [50.7, 50.0], [50.8, 50.0], [50.9, 50.0], [51.0, 51.0], [51.1, 51.0], [51.2, 51.0], [51.3, 51.0], [51.4, 51.0], [51.5, 51.0], [51.6, 51.0], [51.7, 51.0], [51.8, 52.0], [51.9, 52.0], [52.0, 52.0], [52.1, 52.0], [52.2, 52.0], [52.3, 52.0], [52.4, 52.0], [52.5, 52.0], [52.6, 52.0], [52.7, 52.0], [52.8, 53.0], [52.9, 53.0], [53.0, 53.0], [53.1, 53.0], [53.2, 53.0], [53.3, 53.0], [53.4, 54.0], [53.5, 54.0], [53.6, 54.0], [53.7, 54.0], [53.8, 55.0], [53.9, 55.0], [54.0, 55.0], [54.1, 55.0], [54.2, 55.0], [54.3, 55.0], [54.4, 56.0], [54.5, 56.0], [54.6, 56.0], [54.7, 56.0], [54.8, 56.0], [54.9, 56.0], [55.0, 56.0], [55.1, 57.0], [55.2, 57.0], [55.3, 57.0], [55.4, 57.0], [55.5, 57.0], [55.6, 57.0], [55.7, 57.0], [55.8, 58.0], [55.9, 58.0], [56.0, 58.0], [56.1, 58.0], [56.2, 58.0], [56.3, 58.0], [56.4, 58.0], [56.5, 59.0], [56.6, 59.0], [56.7, 59.0], [56.8, 59.0], [56.9, 59.0], [57.0, 59.0], [57.1, 59.0], [57.2, 59.0], [57.3, 60.0], [57.4, 60.0], [57.5, 60.0], [57.6, 60.0], [57.7, 60.0], [57.8, 60.0], [57.9, 61.0], [58.0, 61.0], [58.1, 61.0], [58.2, 61.0], [58.3, 62.0], [58.4, 62.0], [58.5, 62.0], [58.6, 62.0], [58.7, 62.0], [58.8, 62.0], [58.9, 62.0], [59.0, 63.0], [59.1, 63.0], [59.2, 63.0], [59.3, 63.0], [59.4, 63.0], [59.5, 63.0], [59.6, 64.0], [59.7, 64.0], [59.8, 64.0], [59.9, 64.0], [60.0, 64.0], [60.1, 64.0], [60.2, 65.0], [60.3, 65.0], [60.4, 66.0], [60.5, 66.0], [60.6, 66.0], [60.7, 67.0], [60.8, 67.0], [60.9, 67.0], [61.0, 67.0], [61.1, 67.0], [61.2, 67.0], [61.3, 67.0], [61.4, 67.0], [61.5, 68.0], [61.6, 68.0], [61.7, 68.0], [61.8, 69.0], [61.9, 69.0], [62.0, 69.0], [62.1, 69.0], [62.2, 69.0], [62.3, 70.0], [62.4, 70.0], [62.5, 70.0], [62.6, 70.0], [62.7, 71.0], [62.8, 71.0], [62.9, 72.0], [63.0, 72.0], [63.1, 72.0], [63.2, 72.0], [63.3, 73.0], [63.4, 73.0], [63.5, 73.0], [63.6, 73.0], [63.7, 73.0], [63.8, 73.0], [63.9, 74.0], [64.0, 74.0], [64.1, 74.0], [64.2, 74.0], [64.3, 74.0], [64.4, 75.0], [64.5, 75.0], [64.6, 75.0], [64.7, 76.0], [64.8, 76.0], [64.9, 76.0], [65.0, 76.0], [65.1, 77.0], [65.2, 78.0], [65.3, 78.0], [65.4, 78.0], [65.5, 78.0], [65.6, 79.0], [65.7, 79.0], [65.8, 79.0], [65.9, 79.0], [66.0, 80.0], [66.1, 80.0], [66.2, 80.0], [66.3, 81.0], [66.4, 81.0], [66.5, 82.0], [66.6, 83.0], [66.7, 83.0], [66.8, 84.0], [66.9, 84.0], [67.0, 84.0], [67.1, 84.0], [67.2, 85.0], [67.3, 85.0], [67.4, 85.0], [67.5, 86.0], [67.6, 86.0], [67.7, 87.0], [67.8, 87.0], [67.9, 87.0], [68.0, 87.0], [68.1, 88.0], [68.2, 88.0], [68.3, 89.0], [68.4, 89.0], [68.5, 90.0], [68.6, 90.0], [68.7, 91.0], [68.8, 91.0], [68.9, 91.0], [69.0, 92.0], [69.1, 92.0], [69.2, 92.0], [69.3, 93.0], [69.4, 93.0], [69.5, 94.0], [69.6, 94.0], [69.7, 95.0], [69.8, 95.0], [69.9, 95.0], [70.0, 96.0], [70.1, 96.0], [70.2, 96.0], [70.3, 97.0], [70.4, 97.0], [70.5, 97.0], [70.6, 97.0], [70.7, 98.0], [70.8, 98.0], [70.9, 98.0], [71.0, 98.0], [71.1, 99.0], [71.2, 99.0], [71.3, 99.0], [71.4, 100.0], [71.5, 100.0], [71.6, 100.0], [71.7, 100.0], [71.8, 101.0], [71.9, 101.0], [72.0, 101.0], [72.1, 102.0], [72.2, 102.0], [72.3, 102.0], [72.4, 103.0], [72.5, 103.0], [72.6, 103.0], [72.7, 104.0], [72.8, 105.0], [72.9, 105.0], [73.0, 105.0], [73.1, 105.0], [73.2, 106.0], [73.3, 106.0], [73.4, 106.0], [73.5, 107.0], [73.6, 107.0], [73.7, 108.0], [73.8, 108.0], [73.9, 108.0], [74.0, 109.0], [74.1, 109.0], [74.2, 109.0], [74.3, 109.0], [74.4, 109.0], [74.5, 109.0], [74.6, 109.0], [74.7, 110.0], [74.8, 111.0], [74.9, 112.0], [75.0, 113.0], [75.1, 113.0], [75.2, 113.0], [75.3, 114.0], [75.4, 114.0], [75.5, 114.0], [75.6, 114.0], [75.7, 114.0], [75.8, 115.0], [75.9, 115.0], [76.0, 116.0], [76.1, 116.0], [76.2, 116.0], [76.3, 118.0], [76.4, 118.0], [76.5, 119.0], [76.6, 119.0], [76.7, 119.0], [76.8, 119.0], [76.9, 121.0], [77.0, 122.0], [77.1, 122.0], [77.2, 123.0], [77.3, 123.0], [77.4, 123.0], [77.5, 124.0], [77.6, 124.0], [77.7, 125.0], [77.8, 125.0], [77.9, 125.0], [78.0, 126.0], [78.1, 126.0], [78.2, 127.0], [78.3, 128.0], [78.4, 129.0], [78.5, 129.0], [78.6, 130.0], [78.7, 131.0], [78.8, 131.0], [78.9, 132.0], [79.0, 132.0], [79.1, 132.0], [79.2, 133.0], [79.3, 134.0], [79.4, 134.0], [79.5, 134.0], [79.6, 134.0], [79.7, 135.0], [79.8, 135.0], [79.9, 135.0], [80.0, 136.0], [80.1, 136.0], [80.2, 136.0], [80.3, 137.0], [80.4, 138.0], [80.5, 138.0], [80.6, 139.0], [80.7, 140.0], [80.8, 140.0], [80.9, 141.0], [81.0, 142.0], [81.1, 142.0], [81.2, 144.0], [81.3, 144.0], [81.4, 145.0], [81.5, 145.0], [81.6, 146.0], [81.7, 147.0], [81.8, 147.0], [81.9, 147.0], [82.0, 148.0], [82.1, 148.0], [82.2, 150.0], [82.3, 152.0], [82.4, 152.0], [82.5, 152.0], [82.6, 155.0], [82.7, 156.0], [82.8, 156.0], [82.9, 157.0], [83.0, 157.0], [83.1, 158.0], [83.2, 159.0], [83.3, 160.0], [83.4, 160.0], [83.5, 160.0], [83.6, 162.0], [83.7, 163.0], [83.8, 163.0], [83.9, 165.0], [84.0, 165.0], [84.1, 165.0], [84.2, 166.0], [84.3, 167.0], [84.4, 167.0], [84.5, 167.0], [84.6, 169.0], [84.7, 170.0], [84.8, 170.0], [84.9, 171.0], [85.0, 171.0], [85.1, 172.0], [85.2, 174.0], [85.3, 175.0], [85.4, 176.0], [85.5, 177.0], [85.6, 177.0], [85.7, 177.0], [85.8, 178.0], [85.9, 178.0], [86.0, 179.0], [86.1, 180.0], [86.2, 181.0], [86.3, 182.0], [86.4, 182.0], [86.5, 182.0], [86.6, 182.0], [86.7, 184.0], [86.8, 184.0], [86.9, 187.0], [87.0, 187.0], [87.1, 189.0], [87.2, 190.0], [87.3, 191.0], [87.4, 193.0], [87.5, 193.0], [87.6, 196.0], [87.7, 199.0], [87.8, 200.0], [87.9, 201.0], [88.0, 201.0], [88.1, 201.0], [88.2, 202.0], [88.3, 204.0], [88.4, 205.0], [88.5, 205.0], [88.6, 207.0], [88.7, 208.0], [88.8, 209.0], [88.9, 212.0], [89.0, 212.0], [89.1, 212.0], [89.2, 214.0], [89.3, 216.0], [89.4, 218.0], [89.5, 219.0], [89.6, 221.0], [89.7, 222.0], [89.8, 225.0], [89.9, 226.0], [90.0, 226.0], [90.1, 229.0], [90.2, 230.0], [90.3, 233.0], [90.4, 233.0], [90.5, 233.0], [90.6, 235.0], [90.7, 235.0], [90.8, 238.0], [90.9, 240.0], [91.0, 241.0], [91.1, 244.0], [91.2, 247.0], [91.3, 248.0], [91.4, 252.0], [91.5, 253.0], [91.6, 254.0], [91.7, 256.0], [91.8, 256.0], [91.9, 257.0], [92.0, 258.0], [92.1, 260.0], [92.2, 260.0], [92.3, 264.0], [92.4, 266.0], [92.5, 266.0], [92.6, 267.0], [92.7, 269.0], [92.8, 271.0], [92.9, 273.0], [93.0, 276.0], [93.1, 279.0], [93.2, 280.0], [93.3, 282.0], [93.4, 284.0], [93.5, 284.0], [93.6, 287.0], [93.7, 293.0], [93.8, 294.0], [93.9, 295.0], [94.0, 297.0], [94.1, 299.0], [94.2, 301.0], [94.3, 303.0], [94.4, 307.0], [94.5, 311.0], [94.6, 312.0], [94.7, 315.0], [94.8, 316.0], [94.9, 319.0], [95.0, 320.0], [95.1, 322.0], [95.2, 326.0], [95.3, 327.0], [95.4, 330.0], [95.5, 332.0], [95.6, 335.0], [95.7, 343.0], [95.8, 346.0], [95.9, 354.0], [96.0, 355.0], [96.1, 361.0], [96.2, 367.0], [96.3, 370.0], [96.4, 383.0], [96.5, 383.0], [96.6, 392.0], [96.7, 399.0], [96.8, 401.0], [96.9, 411.0], [97.0, 425.0], [97.1, 427.0], [97.2, 439.0], [97.3, 442.0], [97.4, 446.0], [97.5, 457.0], [97.6, 461.0], [97.7, 472.0], [97.8, 486.0], [97.9, 489.0], [98.0, 496.0], [98.1, 503.0], [98.2, 517.0], [98.3, 519.0], [98.4, 520.0], [98.5, 527.0], [98.6, 543.0], [98.7, 554.0], [98.8, 567.0], [98.9, 584.0], [99.0, 592.0], [99.1, 623.0], [99.2, 671.0], [99.3, 678.0], [99.4, 748.0], [99.5, 759.0], [99.6, 870.0], [99.7, 912.0], [99.8, 991.0], [99.9, 1110.0], [100.0, 1330.0]], "isOverall": false, "label": "Products", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 1284.0, "series": [{"data": [[0.0, 1284.0], [600.0, 5.0], [700.0, 4.0], [200.0, 115.0], [800.0, 1.0], [900.0, 4.0], [1000.0, 1.0], [1100.0, 1.0], [300.0, 46.0], [1300.0, 1.0], [100.0, 296.0], [400.0, 23.0], [500.0, 19.0]], "isOverall": false, "label": "Products", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 1300.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 36.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 1764.0, "series": [{"data": [[0.0, 1764.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 36.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 4.714285714285716, "minX": 1.700317529E12, "maxY": 59.97959183673469, "series": [{"data": [[1.700317533E12, 17.628272251308886], [1.700317531E12, 30.335164835164836], [1.700317532E12, 23.687116564417185], [1.700317535E12, 5.2256097560975645], [1.700317536E12, 5.747058823529406], [1.700317534E12, 8.679012345679013], [1.700317538E12, 5.831325301204823], [1.700317537E12, 7.0363636363636335], [1.70031753E12, 47.303370786516844], [1.700317539E12, 4.714285714285716], [1.700317529E12, 59.97959183673469], [1.70031754E12, 13.61904761904762]], "isOverall": false, "label": "线程组", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.70031754E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 16.395833333333332, "minX": 1.0, "maxY": 412.8571428571429, "series": [{"data": [[2.0, 23.066666666666663], [3.0, 16.395833333333332], [4.0, 22.736196319018408], [5.0, 27.082706766917298], [6.0, 35.734693877551], [7.0, 38.813008130081286], [8.0, 44.60919540229885], [9.0, 48.38750000000001], [10.0, 47.909090909090914], [11.0, 60.224137931034484], [12.0, 62.279999999999994], [13.0, 74.5769230769231], [14.0, 61.000000000000014], [15.0, 83.42857142857143], [16.0, 88.66666666666667], [17.0, 98.2], [18.0, 90.25], [19.0, 121.64705882352943], [20.0, 118.66666666666667], [21.0, 132.76000000000005], [22.0, 170.35714285714286], [23.0, 142.99999999999997], [24.0, 137.97916666666669], [25.0, 143.76190476190482], [26.0, 146.0754716981132], [27.0, 151.1190476190476], [28.0, 169.72727272727272], [29.0, 206.2173913043479], [30.0, 223.1818181818182], [31.0, 174.77777777777777], [32.0, 213.0], [33.0, 306.2727272727273], [35.0, 286.0], [34.0, 166.66666666666666], [37.0, 204.46153846153848], [36.0, 203.56249999999997], [38.0, 269.4], [41.0, 140.5], [40.0, 412.8571428571429], [43.0, 343.66666666666663], [42.0, 105.66666666666667], [45.0, 265.1363636363637], [44.0, 222.69230769230768], [47.0, 241.90909090909093], [46.0, 248.45], [49.0, 274.0625], [48.0, 267.55172413793105], [51.0, 218.66666666666669], [50.0, 304.5454545454545], [53.0, 206.5], [52.0, 141.33333333333334], [55.0, 214.0], [54.0, 152.25], [57.0, 163.53846153846155], [56.0, 260.0], [58.0, 183.33333333333334], [59.0, 177.25], [61.0, 169.25], [60.0, 266.3333333333333], [62.0, 172.9], [63.0, 170.0], [65.0, 102.0], [67.0, 165.0], [64.0, 172.0], [1.0, 96.0]], "isOverall": false, "label": "Products", "isController": false}, {"data": [[17.13388888888887, 94.09111111111096]], "isOverall": false, "label": "Products-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 67.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 9934.0, "minX": 1.700317529E12, "maxY": 366473.0, "series": [{"data": [[1.700317533E12, 366473.0], [1.700317531E12, 344542.0], [1.700317532E12, 303912.0], [1.700317535E12, 315271.0], [1.700317536E12, 318976.0], [1.700317534E12, 309051.0], [1.700317538E12, 327944.0], [1.700317537E12, 315765.0], [1.70031753E12, 349092.0], [1.700317539E12, 305638.0], [1.700317529E12, 84987.0], [1.70031754E12, 78206.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.700317533E12, 45104.0], [1.700317531E12, 43092.0], [1.700317532E12, 38552.0], [1.700317535E12, 38751.0], [1.700317536E12, 40184.0], [1.700317534E12, 38300.0], [1.700317538E12, 39189.0], [1.700317537E12, 38915.0], [1.70031753E12, 41932.0], [1.700317539E12, 39859.0], [1.700317529E12, 11562.0], [1.70031754E12, 9934.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.70031754E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 24.327380952380956, "minX": 1.700317529E12, "maxY": 254.5505617977527, "series": [{"data": [[1.700317533E12, 102.97382198952876], [1.700317531E12, 201.01098901098896], [1.700317532E12, 138.29447852760742], [1.700317535E12, 26.652439024390244], [1.700317536E12, 31.523529411764677], [1.700317534E12, 46.94444444444446], [1.700317538E12, 31.228915662650607], [1.700317537E12, 37.55757575757575], [1.70031753E12, 254.5505617977527], [1.700317539E12, 24.327380952380956], [1.700317529E12, 176.02040816326536], [1.70031754E12, 91.23809523809524]], "isOverall": false, "label": "Products", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.70031754E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 24.261904761904766, "minX": 1.700317529E12, "maxY": 254.4887640449437, "series": [{"data": [[1.700317533E12, 102.90575916230362], [1.700317531E12, 200.96703296703305], [1.700317532E12, 138.23926380368107], [1.700317535E12, 26.615853658536594], [1.700317536E12, 31.470588235294116], [1.700317534E12, 46.919753086419746], [1.700317538E12, 31.17469879518073], [1.700317537E12, 37.496969696969686], [1.70031753E12, 254.4887640449437], [1.700317539E12, 24.261904761904766], [1.700317529E12, 175.0612244897959], [1.70031754E12, 91.16666666666669]], "isOverall": false, "label": "Products", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.70031754E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.7619047619047618, "minX": 1.700317529E12, "maxY": 30.142857142857142, "series": [{"data": [[1.700317533E12, 0.968586387434555], [1.700317531E12, 1.1538461538461535], [1.700317532E12, 0.9877300613496934], [1.700317535E12, 0.9573170731707314], [1.700317536E12, 0.9117647058823529], [1.700317534E12, 0.9506172839506168], [1.700317538E12, 0.885542168674699], [1.700317537E12, 0.9939393939393949], [1.70031753E12, 5.898876404494382], [1.700317539E12, 0.7619047619047618], [1.700317529E12, 30.142857142857142], [1.70031754E12, 0.8095238095238092]], "isOverall": false, "label": "Products", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.70031754E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.700317529E12, "maxY": 1330.0, "series": [{"data": [[1.700317533E12, 442.0], [1.700317531E12, 1330.0], [1.700317532E12, 518.0], [1.700317535E12, 114.0], [1.700317536E12, 141.0], [1.700317534E12, 159.0], [1.700317538E12, 114.0], [1.700317537E12, 114.0], [1.70031753E12, 1110.0], [1.700317539E12, 75.0], [1.700317529E12, 351.0], [1.70031754E12, 212.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.700317533E12, 219.60000000000008], [1.700317531E12, 441.1], [1.700317532E12, 265.79999999999995], [1.700317535E12, 52.5], [1.700317536E12, 54.70000000000002], [1.700317534E12, 78.40000000000003], [1.700317538E12, 55.30000000000001], [1.700317537E12, 69.0], [1.70031753E12, 527.4], [1.700317539E12, 47.39999999999998], [1.700317529E12, 301.0], [1.70031754E12, 146.4]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.700317533E12, 428.19999999999976], [1.700317531E12, 1029.5399999999954], [1.700317532E12, 469.99999999999886], [1.700317535E12, 103.59999999999991], [1.700317536E12, 137.44999999999996], [1.700317534E12, 148.29000000000008], [1.700317538E12, 113.33000000000001], [1.700317537E12, 102.78000000000006], [1.70031753E12, 1072.0800000000004], [1.700317539E12, 74.31], [1.700317529E12, 351.0], [1.70031754E12, 212.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.700317533E12, 260.4], [1.700317531E12, 563.3999999999999], [1.700317532E12, 295.9999999999998], [1.700317535E12, 61.75], [1.700317536E12, 75.69999999999993], [1.700317534E12, 106.49999999999994], [1.700317538E12, 74.95000000000002], [1.700317537E12, 83.09999999999997], [1.70031753E12, 660.8999999999996], [1.700317539E12, 56.19999999999993], [1.700317529E12, 333.0], [1.70031754E12, 174.10000000000002]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.700317533E12, 14.0], [1.700317531E12, 29.0], [1.700317532E12, 25.0], [1.700317535E12, 3.0], [1.700317536E12, 12.0], [1.700317534E12, 13.0], [1.700317538E12, 4.0], [1.700317537E12, 14.0], [1.70031753E12, 23.0], [1.700317539E12, 12.0], [1.700317529E12, 39.0], [1.70031754E12, 39.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.700317533E12, 80.0], [1.700317531E12, 143.5], [1.700317532E12, 116.0], [1.700317535E12, 20.0], [1.700317536E12, 25.0], [1.700317534E12, 42.0], [1.700317538E12, 24.5], [1.700317537E12, 34.0], [1.70031753E12, 188.5], [1.700317539E12, 19.0], [1.700317529E12, 167.0], [1.70031754E12, 80.5]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.70031754E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 19.0, "minX": 42.0, "maxY": 188.5, "series": [{"data": [[163.0, 116.0], [162.0, 42.0], [164.0, 20.0], [165.0, 34.0], [166.0, 24.5], [170.0, 25.0], [168.0, 19.0], [42.0, 80.5], [178.0, 188.5], [182.0, 143.5], [191.0, 80.0], [49.0, 167.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 191.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 19.0, "minX": 42.0, "maxY": 188.5, "series": [{"data": [[163.0, 116.0], [162.0, 42.0], [164.0, 20.0], [165.0, 34.0], [166.0, 24.5], [170.0, 25.0], [168.0, 19.0], [42.0, 80.5], [178.0, 188.5], [182.0, 143.5], [191.0, 80.0], [49.0, 167.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 191.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 39.0, "minX": 1.700317529E12, "maxY": 168.0, "series": [{"data": [[1.700317533E12, 167.0], [1.700317531E12, 167.0], [1.700317532E12, 166.0], [1.700317535E12, 166.0], [1.700317536E12, 167.0], [1.700317534E12, 167.0], [1.700317538E12, 167.0], [1.700317537E12, 167.0], [1.70031753E12, 168.0], [1.700317539E12, 162.0], [1.700317529E12, 97.0], [1.70031754E12, 39.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.70031754E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 42.0, "minX": 1.700317529E12, "maxY": 191.0, "series": [{"data": [[1.700317533E12, 191.0], [1.700317531E12, 182.0], [1.700317532E12, 163.0], [1.700317535E12, 164.0], [1.700317536E12, 170.0], [1.700317534E12, 162.0], [1.700317538E12, 166.0], [1.700317537E12, 165.0], [1.70031753E12, 178.0], [1.700317539E12, 168.0], [1.700317529E12, 49.0], [1.70031754E12, 42.0]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.70031754E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 42.0, "minX": 1.700317529E12, "maxY": 191.0, "series": [{"data": [[1.700317533E12, 191.0], [1.700317531E12, 182.0], [1.700317532E12, 163.0], [1.700317535E12, 164.0], [1.700317536E12, 170.0], [1.700317534E12, 162.0], [1.700317538E12, 166.0], [1.700317537E12, 165.0], [1.70031753E12, 178.0], [1.700317539E12, 168.0], [1.700317529E12, 49.0], [1.70031754E12, 42.0]], "isOverall": false, "label": "Products-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.70031754E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 42.0, "minX": 1.700317529E12, "maxY": 191.0, "series": [{"data": [[1.700317533E12, 191.0], [1.700317531E12, 182.0], [1.700317532E12, 163.0], [1.700317535E12, 164.0], [1.700317536E12, 170.0], [1.700317534E12, 162.0], [1.700317538E12, 166.0], [1.700317537E12, 165.0], [1.70031753E12, 178.0], [1.700317539E12, 168.0], [1.700317529E12, 49.0], [1.70031754E12, 42.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.70031754E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

